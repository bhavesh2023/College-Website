<?php
    
?>

<?php
    require_once 'SimpleXLSX.php';
    
    if ( $xlsx = SimpleXLSX::parse('student-mat.xlsx') ) {
      // print_r( $xlsx->rows() );
    } else {
      echo SimpleXLSX::parseError();
    }

    require_once __DIR__ . '/vendor/autoload.php';

    use Phpml\Classification\KNearestNeighbors;
    
    $samples = [[18, 4, 4, 2, 2, 0, 4, 3, 4, 1, 1, 3, 6, 5, 6, 6], [10, 4, 0, 2, 2, 0, 4, 3, 4, 1, 0, 3, 6, 5, 6, 6], [18, 0, 0, 2, 2, 0, 4, 3, 4, 1, 1, 3, 6, 5, 6, 6], [18, 0, 4, 2, 2, 0, 4, 3, 4, 1, 1, 3, 6, 5, 6, 6], [18, 4, 4, 2, 2, 0, 4, 3, 4, 1, 1, 3, 6, 5, 6, 6]];
    $labels = ['home', 'further', 'home', 'military', 'further'];
    $classifier = new KNearestNeighbors();

    echo "training...\n";

    $classifier->train($samples, $labels);

    echo "training complete \n";
    
    $val = $classifier->predict([10, 4, 4, 2, 2, 0, 4, 3, 4, 1, 1, 3, 6, 5, 6, 6]
);

    echo $val;
    ?>